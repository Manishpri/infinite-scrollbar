// //our root app component
import { Component,OnInit } from '@angular/core';
import { HttpClientModule ,HttpHeaders } from '@angular/common/http';
import { MydataserviceService } from './mydataservice.service';
import { Observable } from 'rxjs/Observable';
//
@Component({
  selector: 'my-app',
  styleUrls: ['./app.component.css'],
  templateUrl: './app.component.html',
})

export class AppComponent implements OnInit {

  data = [];
  array = [];
  sum = 19;
  throttle = 99;
  scrollDistance = 1.5;
  direction = '';
  highlighted_indx = null;

  constructor(private service: MydataserviceService) {
   }


  ngOnInit() {
    // To call api
    this.getShares('/');
    if(localStorage.getItem('dataObject')){
      this.highlighted_indx = JSON.parse(localStorage.getItem('dataObject'))["view"]
    }
  }

  getShares(path) {
    return this.service.getShares(path).subscribe((res) => this.onSuccess(res));

  }

  // When we got data on a success
  onSuccess(res) {
    if (res != undefined) {
      res.forEach(item => {
        this.data.push(item);
      });
    }
    if(localStorage.getItem('dataObject')){
      var retrievedObject = JSON.parse(localStorage.getItem('dataObject'));
      var last_used_end = retrievedObject["sum"];
      var last_used_start = retrievedObject["start"];

      if(last_used_start != NaN && last_used_end != NaN){
        this.sum = last_used_end;
        this.appendItems(last_used_start  , last_used_end);
      }

    }else{
        this.appendItems(0, this.sum);
    }
  }

    addItems(startIndex, endIndex) {
      console.log(startIndex,endIndex)
      for (var i = 0; i < endIndex; i++) {
        this.data[i].range = ''
        this.data[i].range = startIndex +' '+ endIndex;
        this.array[i]= this.data[i] ;
      }

      if(localStorage.getItem('dataObject')){
        var checkExist = setInterval(function() {
          var last_view = JSON.parse(localStorage.getItem('dataObject'))["view"];
          this.highlighted_indx = last_view;
          if(last_view != NaN){
            var v_id = 'id_'+last_view;

            if (document.getElementById(v_id)) {
               console.log("Exists!",last_view);
                document.getElementById(v_id).scrollIntoView( {behavior: 'auto', block: 'center', inline: 'center' })
                clearInterval(checkExist);
            }
          }
         }, 100);
     }
  }

    appendItems(startIndex, endIndex) {
      this.addItems(startIndex, endIndex);
    }

    //handling down scroll
    onScrollDown(ev) {

      var start = this.sum;
      if(this.sum < 99){
        console.log('scrolled down!!', ev);
        this.sum += 20;
        this.appendItems(start, this.sum);
        this.direction = 'down'
      }
      else{
          console.log('scrolled down!! else', ev);
        if(this.sum === this.throttle){
          this.sum = 19;
          this.array = this.array.splice(0,19)
        }

        else
            this.sum += 19;
        start = 0;
        this.appendItems(start, this.sum);
        this.direction = 'down';
      }
    }

    onUp(ev) {
      console.log('scrolled up!', ev);
    }

    //selected element function
    selectElm(param,param2){
      this.highlighted_indx = param2;
      var dataObject = {"sum": Number(param.split(' ')[1]) , "start": Number(param.split(' ')[0]),"view":param2 };
      localStorage.setItem('dataObject', JSON.stringify(dataObject));
      console.log(param,param2)
    }
}
