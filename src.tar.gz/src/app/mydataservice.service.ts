import { Injectable } from '@angular/core';
import { HttpClientModule ,HttpHeaders ,HttpClient} from '@angular/common/http';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class MydataserviceService {

  private basePath = '/';
  constructor(private http: HttpClient,private db: AngularFireDatabase) { }

  getShares(path): Observable<any[]> {
    return this.db.list(path).valueChanges();
  }
}
