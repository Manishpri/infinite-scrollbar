export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyB3AUfqTVgs0Q4sSMyetKO9TWEAGV0BQ4Y",
    authDomain: "test-6a05a.firebaseapp.com",
    databaseURL: "https://test-6a05a.firebaseio.com",
    projectId: "test-6a05a",
    storageBucket: "test-6a05a.appspot.com",
    messagingSenderId: "514551999909"
  }
};
